import { useState, useEffect } from 'react';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  GoogleAuthProvider, 
  onAuthStateChanged,
  User as FirebaseUser,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile as firebaseUpdateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  where 
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Detect if Firebase is using placeholder keys
const isEmulated = !firebaseConfig || firebaseConfig.apiKey === 'placeholder-api-key';

let app;
let auth: any = null;
let db: any = null;

if (!isEmulated) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);
  } catch (error) {
    console.warn("Real Firebase initialization failed. Falling back to emulation mode.", error);
  }
}

// Interfaces for our types
export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  bloodGroup: string;
  dob: string;
  heightWeight: string;
  patientId: string;
}

export interface PredictionRecord {
  id: string;
  date: string;
  riskPercentage: number;
  riskLevel: 'Low' | 'Moderate' | 'High';
  age: number;
  gender: string;
  bmi: number;
  glucose: number;
  hba1c: number;
  systolicBP: number;
  diastolicBP: number;
  recommendations: string[];
  clinicalNotes: string;
}

// Default initial user mock profile matching Sarah Jenkins
const DEFAULT_PROFILE: UserProfile = {
  name: "Sarah Jenkins",
  email: "sarahjenkins@gmail.com",
  phone: "+1 (555) 934-2810",
  bloodGroup: "O-Positive (O+)",
  dob: "October 14, 1988 (Age 37)",
  heightWeight: "168 cm / 62 kg (BMI: 22.0)",
  patientId: "MRN-94812-DM"
};

// Default initial history matching previous assessment modal
const DEFAULT_HISTORY: PredictionRecord[] = [
  {
    id: "DS-941",
    date: "June 24, 2026, 10:45 AM",
    riskPercentage: 11,
    riskLevel: "Low",
    age: 37,
    gender: "female",
    bmi: 22.0,
    glucose: 98,
    hba1c: 5.4,
    systolicBP: 115,
    diastolicBP: 75,
    recommendations: ["Maintain current metabolic balance with regular physical activity and optimal hydration."],
    clinicalNotes: "Patient demonstrates robust clinical homeostasis with healthy cell-receptive biomarkers. Current cardiovascular risk profile is highly protective against early diabetes development."
  },
  {
    id: "DS-539",
    date: "March 12, 2026, 02:15 PM",
    riskPercentage: 32,
    riskLevel: "Moderate",
    age: 37,
    gender: "female",
    bmi: 22.0,
    glucose: 114,
    hba1c: 5.9,
    systolicBP: 125,
    diastolicBP: 80,
    recommendations: ["Implement a structured low-glycemic dietary model, omitting simple sugars and refined flours.", "Aim to reduce body mass index by 5-7% over the next 4 months."],
    clinicalNotes: "Patient shows early metabolic dysregulation, placing them in the pre-diabetic risk zone. This state is highly reversible with intensive therapeutic lifestyle modifications, focused weight loss, and refined carbohydrate elimination."
  },
  {
    id: "DS-128",
    date: "November 05, 2025, 09:30 AM",
    riskPercentage: 68,
    riskLevel: "High",
    age: 36,
    gender: "female",
    bmi: 24.2,
    glucose: 135,
    hba1c: 6.7,
    systolicBP: 135,
    diastolicBP: 85,
    recommendations: ["Schedule an urgent fasting plasma glucose/OGTT review with an endocrinologist.", "Monitor daily blood glucose spikes prior to and 2 hours after standard meals."],
    clinicalNotes: "Patient exhibits severe metabolic indicators, predominantly high glycemic blood concentrations and supporting genetic vulnerabilities. Immediate medical screening and insulin resistance review are heavily recommended."
  }
];

// Helper to handle Firestore error formatting for diagnostic capability
function handleFirestoreError(error: unknown, operationType: string, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Setup custom listeners to mimic reactivity in mock/emulated mode
const authListeners = new Set<(user: any) => void>();
let emulatedUser: any = (() => {
  const saved = localStorage.getItem('glucosense_emulated_user');
  if (saved === 'null') return null;
  return saved ? JSON.parse(saved) : {
    uid: "sarah_jenkins_uid",
    displayName: "Sarah Jenkins",
    email: "sarahjenkins@gmail.com",
    photoURL: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150"
  };
})();

function notifyAuthListeners() {
  authListeners.forEach(cb => cb(emulatedUser));
}

// Core unified hook for Auth State
export function useAuth() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isEmulated) {
      setCurrentUser(emulatedUser);
      setLoading(false);
      const cb = (user: any) => {
        setCurrentUser(user);
        setLoading(false);
      };
      authListeners.add(cb);
      return () => {
        authListeners.delete(cb);
      };
    } else {
      if (!auth) {
        setLoading(false);
        return;
      }
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setCurrentUser(user);
        setLoading(false);
      });
      return unsubscribe;
    }
  }, []);

  const loginWithGoogle = async () => {
    if (isEmulated) {
      const user = {
        uid: "sarah_jenkins_uid",
        displayName: "Sarah Jenkins",
        email: "sarahjenkins@gmail.com",
        photoURL: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150"
      };
      emulatedUser = user;
      localStorage.setItem('glucosense_emulated_user', JSON.stringify(user));
      notifyAuthListeners();
      return user;
    } else {
      try {
        const provider = new GoogleAuthProvider();
        const result = await signInWithPopup(auth, provider);
        return result.user;
      } catch (error) {
        console.error("Firebase Login Error", error);
        throw error;
      }
    }
  };

  const registerWithEmailAndPassword = async (email: string, password: string, name: string) => {
    if (isEmulated) {
      const accounts = JSON.parse(localStorage.getItem('glucosense_emulated_accounts') || '[]');
      const user = {
        uid: "user_" + Math.random().toString(36).substring(2, 11),
        displayName: name || email.split('@')[0],
        email: email,
        photoURL: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150"
      };
      accounts.push({ email, password, user });
      localStorage.setItem('glucosense_emulated_accounts', JSON.stringify(accounts));
      
      emulatedUser = user;
      localStorage.setItem('glucosense_emulated_user', JSON.stringify(user));
      notifyAuthListeners();
      return user;
    } else {
      try {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        await firebaseUpdateProfile(result.user, { displayName: name });
        return result.user;
      } catch (error: any) {
        console.error("Firebase SignUp Error", error);
        throw error;
      }
    }
  };

  const loginWithEmailAndPassword = async (email: string, password: string) => {
    if (isEmulated) {
      const accounts = JSON.parse(localStorage.getItem('glucosense_emulated_accounts') || '[]');
      const found = accounts.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
      if (found) {
        if (found.password === password) {
          emulatedUser = found.user;
          localStorage.setItem('glucosense_emulated_user', JSON.stringify(found.user));
          notifyAuthListeners();
          return found.user;
        } else {
          throw new Error("Incorrect password for this registered account.");
        }
      } else {
        // Log in by dynamically registering so the experience is robust and smooth!
        const user = {
          uid: "user_" + Math.random().toString(36).substring(2, 11),
          displayName: email.split('@')[0],
          email: email,
          photoURL: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150"
        };
        accounts.push({ email, password, user });
        localStorage.setItem('glucosense_emulated_accounts', JSON.stringify(accounts));
        emulatedUser = user;
        localStorage.setItem('glucosense_emulated_user', JSON.stringify(user));
        notifyAuthListeners();
        return user;
      }
    } else {
      try {
        const result = await signInWithEmailAndPassword(auth, email, password);
        return result.user;
      } catch (error: any) {
        console.error("Firebase SignIn Error", error);
        throw error;
      }
    }
  };

  const logout = async () => {
    if (isEmulated) {
      emulatedUser = null;
      localStorage.setItem('glucosense_emulated_user', 'null');
      notifyAuthListeners();
    } else {
      try {
        await firebaseSignOut(auth);
      } catch (error) {
        console.error("Firebase Signout Error", error);
        throw error;
      }
    }
  };

  return {
    currentUser,
    loading,
    loginWithGoogle,
    registerWithEmailAndPassword,
    loginWithEmailAndPassword,
    logout
  };
}

// Hook for User Profiles
export function useProfile() {
  const { currentUser } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) {
      setProfile(null);
      setLoading(false);
      return;
    }

    const fetchProfile = async () => {
      setLoading(true);
      if (isEmulated) {
        const saved = localStorage.getItem(`glucosense_profile_${currentUser.uid}`);
        if (saved) {
          setProfile(JSON.parse(saved));
        } else {
          // Setup initial default
          const defaultProf = { ...DEFAULT_PROFILE, email: currentUser.email || DEFAULT_PROFILE.email, name: currentUser.displayName || DEFAULT_PROFILE.name };
          localStorage.setItem(`glucosense_profile_${currentUser.uid}`, JSON.stringify(defaultProf));
          setProfile(defaultProf);
        }
        setLoading(false);
      } else {
        const docPath = `users/${currentUser.uid}`;
        try {
          const docRef = doc(db, docPath);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setProfile(docSnap.data() as UserProfile);
          } else {
            const defaultProf = { ...DEFAULT_PROFILE, email: currentUser.email || DEFAULT_PROFILE.email, name: currentUser.displayName || DEFAULT_PROFILE.name };
            await setDoc(docRef, defaultProf);
            setProfile(defaultProf);
          }
        } catch (error) {
          handleFirestoreError(error, 'get', docPath);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchProfile();
  }, [currentUser]);

  const updateProfile = async (updatedData: Partial<UserProfile>) => {
    if (!currentUser || !profile) return;
    const newProfile = { ...profile, ...updatedData };
    setProfile(newProfile);

    if (isEmulated) {
      localStorage.setItem(`glucosense_profile_${currentUser.uid}`, JSON.stringify(newProfile));
    } else {
      const docPath = `users/${currentUser.uid}`;
      try {
        await setDoc(doc(db, docPath), newProfile, { merge: true });
      } catch (error) {
        handleFirestoreError(error, 'write', docPath);
      }
    }
  };

  return { profile, loading, updateProfile };
}

// Hook for Assessment History
export function useHistory() {
  const { currentUser } = useAuth();
  const [history, setHistory] = useState<PredictionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = async () => {
    if (!currentUser) {
      setHistory([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    if (isEmulated) {
      const saved = localStorage.getItem(`glucosense_history_${currentUser.uid}`);
      if (saved) {
        setHistory(JSON.parse(saved));
      } else {
        localStorage.setItem(`glucosense_history_${currentUser.uid}`, JSON.stringify(DEFAULT_HISTORY));
        setHistory(DEFAULT_HISTORY);
      }
      setLoading(false);
    } else {
      const colPath = `users/${currentUser.uid}/predictions`;
      try {
        const q = query(collection(db, colPath), orderBy('date', 'desc'));
        const querySnapshot = await getDocs(q);
        const records: PredictionRecord[] = [];
        querySnapshot.forEach((doc) => {
          records.push({ id: doc.id, ...doc.data() } as PredictionRecord);
        });

        // Fallback to default if empty on first load to make preview look complete
        if (records.length === 0) {
          for (const item of DEFAULT_HISTORY) {
            await addDoc(collection(db, colPath), item);
            records.push(item);
          }
        }
        setHistory(records);
      } catch (error) {
        handleFirestoreError(error, 'list', colPath);
      } finally {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [currentUser]);

  const addPredictionRecord = async (record: Omit<PredictionRecord, 'id'>) => {
    if (!currentUser) return;
    const newId = `DS-${Math.floor(100 + Math.random() * 900)}`;
    const fullRecord: PredictionRecord = { ...record, id: newId };

    const updatedHistory = [fullRecord, ...history];
    setHistory(updatedHistory);

    if (isEmulated) {
      localStorage.setItem(`glucosense_history_${currentUser.uid}`, JSON.stringify(updatedHistory));
    } else {
      const colPath = `users/${currentUser.uid}/predictions`;
      try {
        await addDoc(collection(db, colPath), fullRecord);
      } catch (error) {
        handleFirestoreError(error, 'write', colPath);
      }
    }
  };

  return { history, loading, addPredictionRecord, refreshHistory: fetchHistory };
}
