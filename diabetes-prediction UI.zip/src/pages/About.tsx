/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { ShieldCheck, HeartPulse, Activity, Sparkles, BookOpen } from 'lucide-react';

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as any } },
  };

  return (
    <div className="relative min-h-screen py-16 md:py-24 overflow-hidden" id="about-page-container">
      {/* Background elements */}
      <div className="absolute inset-0 bg-grid-overlay opacity-5 z-0" />
      <div className="absolute top-1/3 left-0 w-[400px] h-[400px] rounded-full bg-cyan-500/5 blur-[100px] pointer-events-none" />
      
      <div className="mx-auto max-w-7xl px-6 relative z-10">
        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16 md:mb-24"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-cyan-200 bg-cyan-50 px-4 py-1.5 text-xs font-mono text-cyan-700 mb-4 font-semibold">
            <BookOpen className="h-4 w-4 text-cyan-600" />
            <span>PATHOLOGY & BIOCHEMISTRY</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight text-slate-900">
            Understanding <span className="text-cyan-600">Diabetes</span>
          </h1>
          <p className="mt-4 text-slate-500 text-base md:text-lg font-medium">
            A comprehensive overview of the endocrine regulatory loops, insulin signaling pathways, and the biological impact of chronic hyperglycemia.
          </p>
        </motion.div>

        {/* Content Layout: Left Image/SVG, Right Text Content */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center"
        >
          {/* Left Column: Premium Interactive Anatomy / Molecular SVG Illustration */}
          <motion.div 
            variants={itemVariants}
            className="lg:col-span-5 w-full relative"
          >
            <div className="absolute inset-0 bg-cyan-500/5 blur-[50px] rounded-full pointer-events-none" />
            
            <div className="glass-panel border-cyan-500/20 rounded-3xl p-6 shadow-[0_20px_40px_rgba(0,0,0,0.35)] glow-glow-cyan">
              <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                <span className="font-mono text-xs text-cyan-400 font-semibold tracking-wider flex items-center gap-2">
                  <HeartPulse className="h-4 w-4 animate-pulse text-cyan-400" />
                  CELLULAR RECEPTOR BLUEPRINT
                </span>
                <span className="font-mono text-[9px] bg-cyan-500/10 border border-cyan-500/30 rounded px-2 py-0.5 text-cyan-400">
                  FIG. 2.1
                </span>
              </div>

              {/* Vector SVG showing insulin docking with cellular receptor and allowing glucose in */}
              <svg viewBox="0 0 350 400" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto text-cyan-400">
                {/* Cell Membrane Divider Line */}
                <path d="M 20 220 Q 175 250 330 220" stroke="rgba(255,255,255,0.15)" strokeWidth="6" strokeLinecap="round" />
                <path d="M 20 220 Q 175 250 330 220" stroke="rgba(6,182,212,0.3)" strokeWidth="2" strokeDasharray="6,4" />
                <text x="30" y="250" fill="rgba(255,255,255,0.3)" className="font-mono text-[9px] tracking-wider">CELL MEMBRANE</text>
                
                {/* Insulin Receptor Assembly */}
                <g transform="translate(110, 160)">
                  {/* Receptor Y-Shape base */}
                  <path d="M 40 60 L 40 35 L 15 10 M 40 35 L 65 10" stroke="#06b6d4" strokeWidth="4" strokeLinecap="round" />
                  {/* Receptor lock shape */}
                  <circle cx="15" cy="10" r="6" fill="#030712" stroke="#22d3ee" strokeWidth="2" />
                  <circle cx="65" cy="10" r="6" fill="#030712" stroke="#22d3ee" strokeWidth="2" />
                  <text x="10" y="80" fill="rgba(6,182,212,0.8)" className="font-mono text-[9px] font-semibold">INSULIN RECEPTOR</text>
                </g>

                {/* GLUT4 Glucose Transporter Gate */}
                <g transform="translate(220, 180)">
                  {/* Closed Gate Cylinder representation */}
                  <rect x="10" y="10" width="35" height="50" rx="6" fill="#030712" stroke="#0ea5e9" strokeWidth="3" />
                  {/* Unlocked green signal glow */}
                  <line x1="27.5" y1="10" x2="27.5" y2="60" stroke="#10b981" strokeWidth="2" strokeDasharray="3,3" />
                  <text x="-5" y="80" fill="rgba(14,165,233,0.8)" className="font-mono text-[9px] font-semibold">GLUT-4 CHANNEL</text>
                </g>

                {/* floating Insulin particles (Key) */}
                <g transform="translate(100, 70)" className="animate-float">
                  <path d="M 15 15 L 25 25" stroke="#10b981" strokeWidth="3" />
                  <circle cx="25" cy="25" r="5" fill="#10b981" />
                  <text x="35" y="25" fill="#10b981" className="font-mono text-[9px] font-bold">INSULIN (KEY)</text>
                </g>

                {/* glucose molecules (Sugar) */}
                <g className="animate-pulse">
                  {/* molecule 1 */}
                  <circle cx="60" cy="80" r="8" fill="#030712" stroke="#eab308" strokeWidth="2" />
                  <text x="56" y="83" fill="#eab308" className="font-mono text-[8px] font-semibold">G</text>
                  
                  {/* molecule 2 */}
                  <circle cx="280" cy="70" r="8" fill="#030712" stroke="#eab308" strokeWidth="2" />
                  <text x="276" y="73" fill="#eab308" className="font-mono text-[8px] font-semibold">G</text>

                  {/* molecule entering channel */}
                  <circle cx="237" cy="140" r="8" fill="#030712" stroke="#eab308" strokeWidth="2" />
                  <path d="M 237 155 L 237 175" stroke="#eab308" strokeWidth="1.5" strokeLinecap="round" />
                  <text x="233" y="143" fill="#eab308" className="font-mono text-[8px] font-semibold">G</text>
                </g>
              </svg>

              <div className="mt-4 border-t border-white/5 pt-4 text-center">
                <span className="font-mono text-[10px] text-gray-500">
                  Visualization of healthy endocrine insulin-receptive signal pathways.
                </span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Medical Narratives and Explanations */}
          <motion.div 
            variants={itemVariants}
            className="lg:col-span-7 space-y-10"
          >
            {/* Section 1: What is Diabetes */}
            <div className="space-y-3">
              <h2 className="font-display text-2xl font-semibold text-white tracking-wide flex items-center gap-2">
                <span className="text-cyan-400">01.</span> What is Diabetes?
              </h2>
              <p className="text-gray-300 leading-relaxed text-sm md:text-base">
                Diabetes mellitus is a chronic, progressive metabolic disorder characterized by persistent elevation of blood glucose concentrations (hyperglycemia). It stems from absolute deficiency in insulin secretion, resistance to the biological actions of insulin on peripheral target tissues, or a combination of both pathophysiological states.
              </p>
            </div>

            {/* Section 2: Blood Glucose & Insulin Regulatory Loop */}
            <div className="space-y-3">
              <h2 className="font-display text-2xl font-semibold text-white tracking-wide flex items-center gap-2">
                <span className="text-cyan-400">02.</span> The Insulin Regulatory Loop
              </h2>
              <p className="text-gray-300 leading-relaxed text-sm md:text-base">
                Glucose is the fundamental metabolic fuel utilized by human cells. Following digestion, glucose enters the bloodstream. To regulate this influx, the beta-cells of the pancreas secrete <span className="text-cyan-400 font-semibold">Insulin</span>. 
              </p>
              <p className="text-gray-400 text-sm leading-relaxed">
                Insulin acts as a biochemical "key," binding to transmembrane tyrosine kinase receptors. This triggers a downstream signaling cascade causing intracellular vesicles containing GLUT-4 glucose transporters to fuse with the cell membrane, allowing glucose entry and maintaining cellular homeostasis.
              </p>
            </div>

            {/* Section 3: High Blood Sugar & Endocrine Strain */}
            <div className="space-y-3">
              <h2 className="font-display text-2xl font-semibold text-white tracking-wide flex items-center gap-2">
                <span className="text-cyan-400">03.</span> Systemic Pathophysiological Impact
              </h2>
              <p className="text-gray-300 leading-relaxed text-sm md:text-base">
                In individuals with diabetes, this pathway fails. In **Type 1 Diabetes**, autoimmune-mediated beta-cell destruction leaves the body with zero insulin production. In **Type 2 Diabetes**, tissues develop resistance to insulin signals, requiring the pancreas to overproduce insulin until beta-cells burn out.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <h4 className="font-display font-medium text-white text-sm mb-1">Microvascular Hazards</h4>
                  <p className="text-xs text-gray-400">Chronic high sugar damages micro-capillaries, leading to retinopathy (eyes), nephropathy (kidneys), and neuropathy (nerve fibers).</p>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <h4 className="font-display font-medium text-white text-sm mb-1">Macrovascular Hazards</h4>
                  <p className="text-xs text-gray-400">Accelerated lipid plaques in major arteries double the risk of cardiovascular events, myocardial infarctions, and stroke.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
